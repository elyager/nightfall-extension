(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome;function t(){let e=Promise.resolve();return function(t){let n=e.then(t,t);return e=n.then(()=>void 0,()=>void 0),n}}var n={r:0,g:0,b:0,a:1},r=(e,t=1)=>Math.min(t,Math.max(0,e));function i(e,t){if(!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?%?$/i.test(e))return null;let n=Number(e.replace(`%`,``));return Number.isFinite(n)?r(e.endsWith(`%`)?n/100*t:n,t):null}function a(e){let t=e.trim();if(t.toLowerCase()===`transparent`)return{...n,a:0};if(/^#(?:[\da-f]{3,4}|[\da-f]{6}|[\da-f]{8})$/i.test(t))return o(t);let r=t.match(/^(rgba?|color)\((.*)\)$/i);if(!r)return null;let a=r[1].toLowerCase()===`color`,s=r[2].trim();if(a){if(!/^srgb\s/i.test(s))return null;s=s.replace(/^srgb\s+/i,``)}let c,l;if(s.includes(`,`)){if(a||s.includes(`/`))return null;let e=s.split(`,`).map(e=>e.trim());if(e.length!==3&&e.length!==4)return null;c=e.slice(0,3),l=e[3]}else{let e=s.split(`/`);if(e.length>2)return null;c=e[0].trim().split(/\s+/),l=e[1]?.trim()}if(c.length!==3)return null;let u=c.map(e=>i(e,a?1:255)),d=l===void 0?1:i(l,1);if(u.some(e=>e===null)||d===null)return null;let[f,p,m]=u,h=a?255:1;return{r:f*h,g:p*h,b:m*h,a:d}}function o(e){let t=e.trim().replace(/^#/,``);if(!/^(?:[\da-f]{3,4}|[\da-f]{6}|[\da-f]{8})$/i.test(t))throw Error(`Invalid hexadecimal color: ${e}`);let n=t.length<=4?t.split(``).map(e=>e.repeat(2)).join(``):t;return{r:Number.parseInt(n.slice(0,2),16),g:Number.parseInt(n.slice(2,4),16),b:Number.parseInt(n.slice(4,6),16),a:n.length===8?Number.parseInt(n.slice(6,8),16)/255:1}}function s(e){let t=e=>{let t=r(e,255)/255;return t<=.04045?t/12.92:((t+.055)/1.055)**2.4};return .2126*t(e.r)+.7152*t(e.g)+.0722*t(e.b)}function c(e,t){let i=r(e.a),a=r(t.a)*(1-i),o=i+a;return o===0?{...n,a:0}:{r:(e.r*i+t.r*a)/o,g:(e.g*i+t.g*a)/o,b:(e.b*i+t.b*a)/o,a:o}}function l(e,t){let r=t.a<1?c(t,n):t,i=s(c(e,r)),a=s(r);return(Math.max(i,a)+.05)/(Math.min(i,a)+.05)}var u=`nightfallSettings`,d={revision:0,mode:`original`,imageBrightness:100,sites:{}};function f(e){let t=e?.revision,n=Object.fromEntries(Object.entries(e?.sites??{}).map(([e,t])=>{let n=te(t.aiTheme);return[e,{enabled:t.enabled??!0,mode:m(t.mode),repairs:_(t.repairs),...n?{aiTheme:n}:{}}]}));return{revision:Number.isSafeInteger(t)?t:0,mode:m(e?.mode),imageBrightness:p(e?.imageBrightness),sites:n}}function p(e){return typeof e!=`number`||!Number.isFinite(e)?d.imageBrightness:Math.round(Math.min(100,Math.max(40,e)))}function m(e){return e===`original`||e===`dark`||e===`ai`?e:e===`slate-blue`||e===`linear-dark`||e===`github-dark`?`dark`:e===`native`||e===`dimmed-neutral`||e===`off`||e===`on`||e===`auto`?`original`:d.mode}var h=/^#[0-9a-f]{6}$/i,ee=/^rgba\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*(?:0(?:\.\d+)?|1(?:\.0+)?)\s*\)$/i,g=[`pageBackground`,`surface`,`elevatedSurface`,`textPrimary`,`textSecondary`,`textMuted`,`textDisabled`,`border`,`borderSubtle`,`link`,`linkHover`,`linkVisited`,`controlBackground`,`controlHover`,`controlActive`,`controlDisabled`,`focusRing`,`selectionBackground`,`selectionText`,`scrollbarTrack`,`scrollbarThumb`,`scrollbarThumbHover`];function te(e){if(!e||typeof e!=`object`)return;let t=e;for(let e of g)if(typeof t[e]!=`string`||!h.test(t[e]))return;if(typeof t.shadow!=`string`||!ee.test(t.shadow))return;let n=a(t.shadow);if(!n||n.r>255||n.g>255||n.b>255||typeof t.neutralBlend!=`number`||!Number.isFinite(t.neutralBlend))return;let r=o(t.pageBackground),i=o(t.surface),c=o(t.textPrimary),u=o(t.textSecondary),d=o(t.link);if(!(s(r)>.25||s(i)>.32||l(c,r)<4.5||l(c,i)<4.5||l(u,i)<3||l(d,r)<4.5))return{...Object.fromEntries(g.map(e=>[e,t[e]])),id:`ai`,label:`AI`,shadow:t.shadow,neutralBlend:Math.min(.95,Math.max(.55,t.neutralBlend))}}function _(e){if(!Array.isArray(e))return[];let t=new Set;return e.filter(e=>!!(e&&typeof e==`object`)).flatMap(e=>{let n=typeof e.selector==`string`?e.selector.trim():``,r=typeof e.path==`string`?e.path:``;if(!n||n.length>1e3||!r.startsWith(`/`))return[];let i=`${r}\n${n}`;return t.has(i)?[]:(t.add(i),[{selector:n,path:r}])}).slice(0,100)}async function v(){return f((await e.storage.local.get(u))[u])}async function ne(t){await e.storage.local.set({[u]:t})}function y(e,t){let n=e.sites[t],r=n??re(e,t),i=n?.aiTheme??r?.aiTheme;return{enabled:r?.enabled??!0,mode:r?.mode??`original`,repairs:n?.repairs??[],...i?{aiTheme:i}:{}}}function re(e,t){let n=t.toLowerCase().split(`.`);for(let t=1;t<n.length-1;t+=1){let r=e.sites[n.slice(t).join(`.`)];if(r)return r}}function b(e,t,n){let r=y(e,t);return{...e,sites:{...e.sites,[t]:{...r,...n}}}}var x=`nightfallAiCredentials`,S=`nightfallAiLogs`;function C(e){let t=e.replace(/^\[|\]$/g,``);return/^[\d.]+$/.test(t)||t.includes(`:`)}function w(e){try{let t=new URL(e);if(![`http:`,`https:`].includes(t.protocol))return null;let n=C(t.hostname)?t.hostname:`*.${t.hostname}`;return`${t.protocol}//${n}/*`}catch{return null}}function T(e){try{return(typeof e==`string`?new URL(e):e).pathname||`/`}catch{return`/`}}function E(e,t){return e.filter(e=>e.path===t)}var D=document.querySelector(`#app`),O=d,k,A=``,j=``,M=!1,N=``,P=!1,F=``,I=!1,L=!0,R=[],z=0,B=t();D.innerHTML=`<p class="popup-loading" role="status">Loading Nightfall…</p>`;var V=[{mode:`original`,label:`Original`,title:`Use the website’s default appearance`},{mode:`dark`,label:`Dark`,title:`Readable dark surfaces that preserve the website’s colors`},{mode:`ai`,label:`AI`,title:`Generate a dark palette with OpenRouter using aggregate page styles`}];async function H(){let t=(await e.storage.local.get(x))[x];N=typeof t?.openRouterApiKey==`string`?t.openRouterApiKey:``}async function U(t){N=t.trim(),await e.storage.local.set({[x]:{openRouterApiKey:N}})}async function W(){N=``,await e.storage.local.remove(x)}async function G(){let t=await e.storage.local.get(S);R=Array.isArray(t.nightfallAiLogs)?t[S].slice(0,20):[]}async function K(){R=[],await e.storage.local.remove(S)}async function ie(){let t=Number(new URLSearchParams(location.search).get(`tab`)),n=Number.isInteger(t)&&t>0?await e.tabs.get(t):(await e.tabs.query({active:!0,currentWindow:!0}))[0];k=n?.id,j=n?.url??``;try{A=j?new URL(j).hostname:``}catch{A=``}let r=q();M=r?await e.permissions.contains({origins:[r]}):!1}function q(){return w(j)}async function J(){if(!k||!M)return null;try{let t=await e.tabs.sendMessage(k,{type:`GET_STATUS`},{frameId:0});return t?.ok&&`status`in t?t.status:null}catch{return null}}async function Y(){if(!k||!M)return!1;try{return(await e.runtime.sendMessage({type:`ENSURE_CONTENT_SCRIPT`,tabId:k}))?.ok===!0}catch{return!1}}async function ae(){let t=((await e.permissions.getAll()).origins??[]).filter(e=>e!==`https://openrouter.ai/*`&&(e.startsWith(`http://`)||e.startsWith(`https://`)));t.length&&(await e.permissions.remove({origins:t}),M=!1,await $())}async function oe(t){if(!k||!M||!await Y())return null;try{let n=await e.tabs.sendMessage(k,{type:`APPLY_SETTINGS`,settings:t},{frameId:0});return n?.ok&&`status`in n?n.status:null}catch{return null}}async function X(e){let t=++z;O={...e,revision:O.revision+1};let n=O;Z(null);try{let[e]=await Promise.all([oe(n),B(()=>ne(n))]);if(t!==z)return;Z(e??await J())}catch{t===z&&await $()}}function Z(e){let t=A?y(O,A):y(O,``),n=t.enabled?t.mode:`original`,r=E(t.repairs,T(j)),i=!!t.aiTheme,a=n===`ai`||I,o=V.map(({mode:t,label:r,title:i})=>{let a=e?e.nativeDark?`Dark`:`Light`:`Detecting…`;return`
        <button class="mode-button" data-mode="${t}" aria-pressed="${n===t}" aria-label="${t===`original`?`Original - ${a}`:r}" title="${i}">
          <span>${r}</span>
          ${t===`original`?`<small>${a}</small>`:``}
        </button>`}).join(``);D.innerHTML=`
    <header>
      <img class="mark" src="/icon/48.png" width="34" height="34" alt="" />
      <div>
        <h1>Nightfall</h1>
        <p class="site">${A||`This page is protected`}</p>
      </div>
    </header>

    ${M?`<section class="mode" aria-label="Page appearance">${o}</section>`:``}

    ${M?`
      <section class="image-brightness" aria-label="Image brightness">
        <div class="image-brightness-heading">
          <label for="image-brightness"><strong>Image brightness</strong><small>Dims photos without changing their colors</small></label>
          <output id="image-brightness-value" for="image-brightness">${O.imageBrightness}%</output>
        </div>
        <input id="image-brightness" type="range" min="40" max="100" step="1" value="${O.imageBrightness}" ${n===`original`?`disabled`:``} />
        ${n===`original`?`<small class="image-brightness-hint">Choose Dark or AI to apply image brightness.</small>`:``}
      </section>
    `:``}

    ${M&&a?`
      <section class="ai-theme" aria-label="AI-generated appearance">
        <div class="ai-heading">
          <div><strong>AI theme</strong><small>${i?`Generated palette saved for this site`:`Uses aggregate styling only`}</small></div>
          ${N?`<button class="regenerate-ai" id="forget-ai-key">Forget key</button>`:``}
        </div>
        ${N?`
          <div class="saved-key"><span aria-hidden="true">✓</span><div><strong>API key saved</strong><small>Stored in Nightfall's extension-only browser storage</small></div></div>
        `:`
          <label class="api-key-label" for="openrouter-key">OpenRouter API key</label>
          <input id="openrouter-key" type="password" autocomplete="off" spellcheck="false" placeholder="sk-or-v1-…" aria-describedby="ai-privacy" />
        `}
        <p id="ai-privacy">Generate sends aggregate colors, font categories, spacing, and element counts to OpenRouter and its selected AI provider. Your API key is sent only to OpenRouter to authenticate the request. Page text, URLs, selectors, IDs, classes, form values, cookies, and browser storage are excluded. <a href="https://nightfall-elyager.netlify.app/privacy-policy.html" target="_blank" rel="noreferrer">Privacy policy</a></p>
        <label class="zdr-option">
          <input id="require-zdr" type="checkbox" ${L?`checked`:``} />
          <span><strong>Require zero-data retention</strong><small>Turn this off only if no free ZDR provider is available.</small></span>
        </label>
        <button class="generate-ai" id="generate-ai" ${P?`disabled`:``}>${P?`Generating…`:i?`Generate again`:`Generate and apply`}</button>
        ${F?`<p class="ai-error" role="alert">${Q(F)}</p>`:``}
        ${R.length?`
          <details class="ai-logs">
            <summary>OpenRouter logs (${R.length})</summary>
            <div class="ai-log-toolbar"><small>Stored locally · API key and request payload excluded</small><button id="clear-ai-logs">Clear</button></div>
            ${R.map(e=>`
              <article class="ai-log-entry ${e.ok?`is-success`:`is-error`}">
                <header><strong>${e.ok?`Success`:`Error`} · HTTP ${e.httpStatus||`network`}</strong><time>${Q(new Date(e.timestamp).toLocaleString())}</time></header>
                <small>Attempt ${e.attempt??1} · ZDR ${e.requireZdr?`required`:`not required`}</small>
                ${e.error?`<p>${Q(e.error)}</p>`:``}
                <pre>${Q(e.responseText||`(empty response body)`)}</pre>
              </article>
            `).join(``)}
          </details>
        `:``}
      </section>
    `:``}

    ${M?`
      <section class="element-fixes" aria-label="Element fixes">
        <div class="fix-copy">
          <strong>Fix an element</strong>
          <small>${r.length?`${r.length} saved on this page`:`Pick anything the theme missed`}</small>
        </div>
        <button class="inspect-button" id="inspect-element" title="Select an element on the page" ${n===`original`?`disabled`:``}>
          <svg viewBox="0 0 20 20" aria-hidden="true"><path d="M3.5 2.5h7v2h-5v5h-2v-7Zm6.9 6.25 6.1 2.42-2.6 1.18 1.57 3.15-1.8.9-1.55-3.13-2.22 2.13.5-6.65Z"/></svg>
          Inspect
        </button>
        ${r.length?`<button class="clear-fixes" id="clear-fixes" title="Remove saved fixes from this page">Clear</button>`:``}
      </section>
      ${n===`original`?`<p class="fix-hint">Choose Dark or AI before fixing elements.</p>`:``}
    `:``}

    ${M?``:`
      <section class="permission">
        <strong>Allow Nightfall on this site</strong>
        <p>Access includes this site’s subdomains and is used only on this device.</p>
        <button id="grant-access" ${A?``:`disabled`}>Allow this site</button>
      </section>
    `}

    

    <footer>No tracking · Dark mode runs on your device<br /><a href="https://nightfall-elyager.netlify.app/privacy-policy.html" target="_blank" rel="noreferrer">Privacy</a> · <a href="https://nightfall-elyager.netlify.app/#contact" target="_blank" rel="noreferrer">Support</a></footer>
  `,ce()}function Q(e){return e.replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e])}async function se(){if(!k||!A||P)return;let t=D.querySelector(`#openrouter-key`)?.value.trim()||N;if(!t){F=`Enter your OpenRouter API key first.`,Z(await J());return}P=!0,F=``,N=t,Z(null);try{if(!await e.permissions.request({origins:[`https://openrouter.ai/*`]}))throw Error(`OpenRouter access was not allowed.`);if(await U(t),!await Y())throw Error(`Nightfall could not inspect this page.`);let n;for(let t=0;t<2&&(n=await e.tabs.sendMessage(k,{type:`GET_PAGE_STYLE_SNAPSHOT`},{frameId:0}).catch(()=>void 0),!(n?.ok&&`snapshot`in n));t+=1)await Y();if(!n?.ok||!(`snapshot`in n))throw Error(`Nightfall received no page-style response. Reload the page and try again.`);let r=await e.runtime.sendMessage({type:`GENERATE_AI_THEME`,apiKey:t,snapshot:n.snapshot,requireZdr:L});if(!r)throw Error(`Nightfall received no background response. Reopen the extension and try again.`);if(!r.ok||!r.theme)throw Error(r.ok?`No theme was returned.`:r.error);await X({...b(O,A,{enabled:!0,mode:`ai`,aiTheme:r.theme}),mode:`ai`})}catch(e){let t=e instanceof Error?e.message:`Unable to generate the AI theme.`;F=L&&/no endpoints found matching your data policy/i.test(t)?`No free zero-data-retention provider is currently available. Configure OpenRouter privacy, or turn off the ZDR requirement below and retry.`:t}finally{P=!1,await G(),Z(await J())}}function ce(){D.querySelectorAll(`[data-mode]`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.mode;if(t===`ai`&&!y(O,A).aiTheme){I=!0,Z(null),D.querySelector(`#openrouter-key`)?.focus();return}let n=y(O,A);!A||n.enabled&&t===n.mode||X({...b(O,A,{mode:t,enabled:!0}),mode:t})})});let t=D.querySelector(`#image-brightness`),n=D.querySelector(`#image-brightness-value`);t?.addEventListener(`input`,()=>{n&&(n.value=`${t.value}%`)}),t?.addEventListener(`change`,()=>{let e=Number(t.value);!Number.isFinite(e)||e===O.imageBrightness||X({...O,imageBrightness:e})}),D.querySelector(`#generate-ai`)?.addEventListener(`click`,()=>{se()}),D.querySelector(`#require-zdr`)?.addEventListener(`change`,e=>{L=e.currentTarget.checked,F=``}),D.querySelector(`#forget-ai-key`)?.addEventListener(`click`,()=>{W().then(()=>Z(null))}),D.querySelector(`#clear-ai-logs`)?.addEventListener(`click`,e=>{e.preventDefault(),K().then(()=>Z(null))}),D.querySelector(`#grant-access`)?.addEventListener(`click`,async()=>{let t=q();if(!(!t||!k)){if(e.runtime.sendMessage({type:`ARM_POPUP_REOPEN`,tabId:k,pattern:t}),!await e.permissions.request({origins:[t]})){e.runtime.sendMessage({type:`DISARM_POPUP_REOPEN`});return}M=!0,Z(null),Y().then($)}}),D.querySelector(`#reset-allowed-sites`)?.addEventListener(`click`,()=>{ae()}),D.querySelector(`#inspect-element`)?.addEventListener(`click`,async()=>{if(!(!k||!await Y()))try{(await e.tabs.sendMessage(k,{type:`START_ELEMENT_PICKER`},{frameId:0}))?.ok&&window.close()}catch{await $()}}),D.querySelector(`#clear-fixes`)?.addEventListener(`click`,()=>{if(!A)return;let e=y(O,A),t=T(j);X(b(O,A,{repairs:e.repairs.filter(e=>e.path!==t)}))})}async function $(){Z(await J())}async function le(){try{[O]=await Promise.all([v(),ie(),H(),G()]),Z(null),k&&Promise.all([e.action.setBadgeText({text:``,tabId:k}),e.action.setTitle({title:`Nightfall`,tabId:k})]).catch(()=>void 0),await Y(),await $()}catch(e){console.error(`Unable to initialize the Nightfall popup`,e),Z(null)}}le();